from tabelas import *
from consultas import *
from sqlalchemy import *



def main():
    print(tables())
main()